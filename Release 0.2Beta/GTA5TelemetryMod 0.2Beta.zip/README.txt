﻿INSTALLATION INSTRUCTIONS 
=========================

This mod make GTA5 behave as a Codemaster Game, sending telemetry data in the same format as Dirt Rally.
This makes it compatible with any dashboard that supports Codemasters game.
It has been tested with Simhub and my Arduino Dashboard.

To run my plugin you need the "Script Hook C" and the "Community Script Hook V .NET" mods.

1. Download and install OpenIV 
===============================
OpenIV is a modding tool that support recent Rockstar games.
https://it.gta5-mods.com/tools/openiv

2. Launch OpenIV, configure it for GTA V game, specifying your game installation path, then go in the "Tools" Menu and install the "ASI Manager". This is required in order to execute the .ASI plugins for GTA V.

3. Download and install Script Hook V + Native Trainer 1.0.1032.1
=================================================================
Download from: https://www.gta5-mods.com/tools/script-hook-v

4. Download and install Community Script Hook V .NET 2.9.6
==========================================================
Download from: https://github.com/crosire/scripthookvdotnet/releases
Download from: https://it.gta5-mods.com/tools/scripthookv-net

5. Create a "script" folder in your GTA5 installation root folder and copy
my Gta5CodemastersTelemetry.dll there

[OPTIONAL]
I recommend to use my work in conjunction with the Manual Transimission Mod

4. Download and install Manual Transmission & Steering Wheel Support v4.3.1 
===========================================================================
Download from: https://www.gta5-mods.com/scripts/manual-transmission-ikt

5. Download and install Realistic Driving V v2.2 
=====================================================================
Download from: https://www.gta5-mods.com/vehicles/realistic-driving-v


